-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 12-10-2023 a las 17:10:18
-- Versión del servidor: 8.0.30
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `transito`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `multas`
--

CREATE TABLE `multas` (
  `id` int NOT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `placas` varchar(10) DEFAULT NULL,
  `usuario_id` varchar(200) DEFAULT NULL,
  `ubicacion` varchar(255) DEFAULT NULL,
  `infraccion` varchar(255) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  `plazo_cumplimiento` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `multas`
--

INSERT INTO `multas` (`id`, `fecha`, `hora`, `placas`, `usuario_id`, `ubicacion`, `infraccion`, `descripcion`, `monto`, `plazo_cumplimiento`) VALUES
(2, '2023-10-12', '11:20:00', 'ASD545', 'malvin', 'medellin', 'prueba', 'ssssssssssssssssssssssssssssssssssssssssssss', 23456.00, '2023-10-18'),
(3, '2023-10-12', '11:20:00', 'ASD545', 'rosa', 'medellin', 'prueba', 'ssssssssssssssssssssssssssssssssssssssssssss', 23456.00, '2023-10-18'),
(4, '2023-10-12', '11:20:00', 'ASD545', 'malvin', 'medellin', 'prueba', 'ssssssssssssssssssssssssssssssssssssssssssss', 23456.00, '2023-10-18'),
(6, '2023-10-14', '11:50:00', 'sssss', 'sssssssssss', 'ssssssssssss', 'dsssss', 'dssssssssssss', 12213.00, '2023-10-19'),
(8, '2023-10-12', '11:20:00', 'ASD545', 'malvin', 'medellin', 'prueba', 'hoy', 23456.00, '2023-10-18'),
(9, '2023-10-12', '11:20:00', 'ASD545', 'malvin', 'medellin', 'prueba', 'ha', 23456.00, '2023-10-18'),
(10, '2023-10-12', '11:20:00', 'ASD545', 'elefannte  ', 'medellin', 'prueba', 'ssssssssssssssssssssssssssssssssssssssssssss', 23456.00, '2023-10-18'),
(11, '2023-10-12', '11:20:00', 'ASD545', 'malvin  ruso', 'medellin', 'prueba         dre', 'ssssssssssssssssssssssssssssssssssssssssssss', 23456.00, '2023-10-18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `multas`
--
ALTER TABLE `multas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `multas`
--
ALTER TABLE `multas`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
