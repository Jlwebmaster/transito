<?php
$idmulta = $_GET['id'];
require_once "back/conexion.php";

// Query to retrieve the multa data
$query = "SELECT * FROM multas WHERE id = " . $idmulta;
$result = $conn->query($query);

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    $fecha = $row["fecha"];
    $hora = $row["hora"];
    $placas = $row["placas"];
    $usuario = $row["usuario_id"];
    $ubicacion = $row["ubicacion"];
    $infraccion = $row["infraccion"];
    $descripcion = $row["descripcion"];
    $monto = $row["monto"];
    $plazo = $row["plazo_cumplimiento"];
} else {
    // Handle the case where the multa with the given ID is not found
    echo "Multa no encontrada.";
}

$conn->close();
?>

<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<html>
<head>
    <title>Sistema de Multas de Tráfico</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-center">Editar Multa</h2>

        <!-- Formulario para editar la multa -->
        <form action="back/editarcomparendo.php" method="post">
            <div class="form-group">
                <label for="fecha">Fecha:</label>
                <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo $fecha; ?>">
            </div>

            <div class="form-group">
                <label for="hora">Hora:</label>
                <input type="time" class="form-control" id="hora" name="hora" value="<?php echo $hora; ?>">
            </div>

            <div class="form-group">
                <label for="placas">Placas:</label>
                <input type="text" class="form-control" id="placas" name="placas" value="<?php echo $placas; ?>">
            </div>

            <div class="form-group">
                <label for="usuario">Usuario:</label>
                <input type="text" class="form-control" id="usuario" name="usuario" value="<?php echo $usuario; ?>">
            </div>

            <div class="form-group">
                <label for="ubicacion">Ubicación:</label>
                <input type="text" class="form-control" id="ubicacion" name="ubicacion" value="<?php echo $ubicacion; ?>">
            </div>

            <div class="form-group">
                <label for="infraccion">Infracción:</label>
                <input type="text" class="form-control" id="infraccion" name="infraccion" value="<?php echo $infraccion; ?>">
            </div>

            <div class="form-group">
                <label for="descripcion">Descripción:</label>
                <input type="text" class="form-control" id="descripcion" name="descripcion" value="<?php echo $descripcion; ?>">
            </div>

            <div class="form-group">
                <label for="monto">Monto:</label>
                <input type="text" class="form-control" id="monto" name="monto" value="<?php echo $monto; ?>">
            </div>

            <div class="form-group">
                <label for="plazo">Plazo de Cumplimiento:</label>
                <input type="date" class="form-control" id="plazo" name="plazo" value="<?php echo $plazo; ?>">
            </div>
            <input type="hidden" name="id" value="<?php echo $idmulta; ?>">
            <input type="submit" class="btn btn-primary" value="Guardar Comparendo">
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="script.js"></script>
</body>
</html>
