<?php
$id_comparendo = $_GET['id'];
require_once "back/conexion.php"; // Asegúrate de incluir tu archivo de conexión

// Consulta SQL para eliminar el comparendo con el ID proporcionado
$query = "DELETE FROM multas WHERE id = ?";

if ($stmt = $conn->prepare($query)) {
    $stmt->bind_param("i", $id_comparendo); // "i" indica que es un entero (ID)
    
    if ($stmt->execute()) {
        // Eliminación exitosa, puedes redirigir o mostrar un mensaje
        echo '<script>alert("Comparendo eliminado con éxito.");</script>';
        echo '<script>window.location = "index.php";</script>';
    } else {
        // Error en la eliminación
        echo "Error en la eliminación: " . $stmt->error;
    }
    
    $stmt->close();
} else {
    echo "Error en la preparación de la consulta: " . $conn->error;
}

$conn->close();



?>