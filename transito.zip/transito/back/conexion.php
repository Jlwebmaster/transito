<?php
$servername = "localhost";
$username = "root";  // Reemplaza "tu_usuario" con tu nombre de usuario de MySQL
$password = "";  // Reemplaza "tu_contraseña" con tu contraseña de MySQL
$database = "transito";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Si llegas a este punto, la conexión a la base de datos fue exitosa
// Puedes usar la variable $conn para interactuar con la base de datos
?>
