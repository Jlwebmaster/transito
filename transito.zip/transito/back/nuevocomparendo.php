<?php
require_once "conexion.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fecha = $_POST["fecha"];
    $hora = $_POST["hora"];
    $placas = $_POST["placas"];
    $usuario = $_POST["usuario"];
    $ubicacion = $_POST["ubicacion"];
    $infraccion = $_POST["infraccion"];
    $descripcion = $_POST["descripcion"];
    $monto = $_POST["monto"];
    $plazo = $_POST["plazo"];

    // SQL query to insert data into the 'multas' table
    $sql = "INSERT INTO multas (fecha, hora, placas,usuario_id, ubicacion, infraccion, descripcion, monto, plazo_cumplimiento) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Bind the parameters
        $stmt->bind_param("sssssssss", $fecha, $hora, $placas, $usuario, $ubicacion, $infraccion, $descripcion, $monto, $plazo);

        // Execute the statement
        if ($stmt->execute()) {
            echo '<script>';
            echo 'alert("Multa guardada exitosamente!");';
            echo 'window.location.href = "../index.php";';
            echo '</script>';
        } else {
            echo "Error al guardar la multa: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
}

?>