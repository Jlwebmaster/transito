<?php
require_once "conexion.php";

// Verifica si se enviaron datos por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera los valores del formulario
    $id = $_POST["id"];
    $fecha = $_POST["fecha"];
    $hora = $_POST["hora"];
    $placas = $_POST["placas"];
    $usuario = $_POST["usuario"];
    $ubicacion = $_POST["ubicacion"];
    $infraccion = $_POST["infraccion"];
    $descripcion = $_POST["descripcion"];
    $monto = $_POST["monto"];
    $plazo = $_POST["plazo"];

    // Query de actualización
    $query = "UPDATE multas SET fecha = '$fecha', hora = '$hora', placas = '$placas', usuario_id = '$usuario', ubicacion = '$ubicacion', infraccion = '$infraccion', descripcion = '$descripcion', monto = '$monto', plazo_cumplimiento = '$plazo' WHERE id = $id";

    if ($conn->query($query) === TRUE) {
        // Actualización exitosa, redirige a la página de inicio
        echo '<script>alert("Datos cambiados con éxito.");</script>';
        echo '<script>window.location = "../index.php";</script>';
    } else {
        echo "Error en la actualización: " . $conn->error;
    }
} else {
    echo "Acceso no autorizado.";
}

$conn->close();
?>
