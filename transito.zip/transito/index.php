<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<html>
<head>
    <title>Sistema de Multas de Tráfico</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <h2>Registro de Multas</h2>
    <a class="btn btn-primary mb-2" href="nuevamulta.html">Agregar Multa</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th># Multa</th>
                <th>Fecha</th>
                <th>Hora</th>
                <th>Placas</th>
                <th>Usuario</th>
                <th>Ubicacion</th>
                <th>Infracion</th>
                <th>Descripción</th>
                <th>Monto</th>
                <th>Plazo de Cumplimiento</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody id="multaTable">
           <?php
           require_once "back/conexion.php";
           $query = "SELECT * FROM multas";
           $result = $conn->query($query);

           // Comprobar si se obtuvieron resultados
           if ($result->num_rows > 0) {
               while ($row = $result->fetch_assoc()) {
                   echo "<tr>";
                   echo "<td>" . $row["id"] . "</td>";
                   echo "<td>" . $row["fecha"] . "</td>";
                   echo "<td>" . $row["hora"] . "</td>";
                   echo "<td>" . $row["placas"] . "</td>";
                   echo "<td>" . $row["usuario_id"] . "</td>";
                   echo "<td>" . $row["ubicacion"] . "</td>";
                   echo "<td>" . $row["infraccion"] . "</td>";
                   echo "<td>" . $row["descripcion"] . "</td>";
                   echo "<td>" . $row["monto"] . "</td>";
                   echo "<td>" . $row["plazo_cumplimiento"] . "</td>";
                   echo "<td><button class='btn btn-primary' onclick='editarMulta(" . $row["id"] . ")'>Editar</button>";
                   echo " <button class='btn btn-danger' onclick='eliminarMulta(" . $row["id"] . ")'>Eliminar</button></td>";
                   echo "</tr>";
               }
           } else {
               echo "No se encontraron multas.";
           }
           $conn->close();
           ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="script.js"></script>

<script>
    function editarMulta(multaId) {
        // Redirige a la página de edición y pasa el ID como parámetro en la URL
        window.location.href = 'editarmulta.php?id=' + multaId;
    }

    function eliminarMulta(multaId) {
        // Redirige a la página de eliminación y pasa el ID como parámetro en la URL
        window.location.href = 'eliminarcomparendo.php?id=' + multaId;
    }
</script>


</body>
</html>
